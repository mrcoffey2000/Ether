# ETHER

Selection discipline. One watch. Every Friday.

## Deploy to Vercel

1. Create new repo on GitHub
2. Upload these files:
   - `index.html`
   - `vercel.json`
3. Go to vercel.com
4. Sign in with GitHub
5. Import your repo
6. Deploy (no config needed)

Done. Live in 30 seconds.

## Local Testing

Open `index.html` in Safari or Chrome.

## Stack

- Pure HTML/CSS/JS
- Inter font (Google Fonts)
- No framework
- No build step

## Brand

Black void. Inter only. Time governs loss. Mercy endures.

Est. 2025
